﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace pracownik
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private string haslo;

        private void btnHaslo_Click(object sender, RoutedEventArgs e)
        {
            Random random = new Random();

            string litery = "qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM";
            string cyfry = "0123456789";
            string znaki = "!@#$%^&*()_+-=";

            string pula_znakow = "";
            haslo = "";

            int liczba_znakow = 0;
            if (!string.IsNullOrWhiteSpace(txtZnakow.Text.Trim()))
            {
                liczba_znakow = int.Parse(txtZnakow.Text.Trim());

                if (checkLitery.IsChecked == true)
                {
                    pula_znakow += litery;
                }
                if (checkCyfry.IsChecked == true)
                {
                    haslo += cyfry[random.Next(0, cyfry.Length - 1)];
                    liczba_znakow--;
                    pula_znakow += cyfry;
                }
                if (checkZnaki.IsChecked == true)
                {
                    haslo += znaki[random.Next(0, znaki.Length - 1)];
                    liczba_znakow--;
                    pula_znakow += znaki;
                }

                if (pula_znakow.Length > 0)
                {
                    for (int i = 0; i < liczba_znakow; i++)
                    {
                        haslo += pula_znakow[random.Next(0, pula_znakow.Length - 1)];
                    }
                    MessageBox.Show($"{haslo}");
                }
                else
                {
                    MessageBox.Show("Nie zaznaczono żadnej opcji");
                }
            }
        }

        private void btnZatwierdz_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show($"Dane pracownika: {txtImie.Text.Trim()} {txtNazwisko.Text.Trim()} {cbStanowisko.Text.Trim()}, Hasło: {haslo}");
        }
    }
}