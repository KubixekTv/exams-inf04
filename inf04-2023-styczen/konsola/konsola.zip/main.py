import unittest


def euklides(a: int, b: int):
    while a != b:
        if a > b:
            a = a - b
        else:
            b = b - a

    return a


class TestJednostkowy(unittest.TestCase):
    def test_dodaj(self):
        self.assertEqual(euklides(27, 9), 9)


if __name__ == '__main__':
    unittest.main()
