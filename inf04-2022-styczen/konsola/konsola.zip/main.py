import random

class SortowaniePrzezWybor:
    def __init__(self, tab: list):
        self.tab = tab

    def sortowanie(self):
        for i in range(len(self.tab)):
            max_i = self.maksymalna(i)
            self.tab[max_i], self.tab[i] = self.tab[i], self.tab[max_i]

        return self.tab

    def maksymalna(self, i):
        max_i = i
        for j in range(i, len(self.tab)):
            if self.tab[j] > self.tab[max_i]:
                max_i = j

        return max_i


if __name__ == "__main__":
    tab = []
    for i in range(10):
        tab.append(random.randint(0, 100))

    print(tab)

    sorter = SortowaniePrzezWybor(tab)
    
    print(sorter.sortowanie())
