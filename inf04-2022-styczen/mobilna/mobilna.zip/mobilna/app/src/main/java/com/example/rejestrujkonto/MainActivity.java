package com.example.rejestrujkonto;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        EditText inputEmail = findViewById(R.id.editTextText);
        EditText inputHaslo1 = findViewById(R.id.editTextText2);
        EditText inputHaslo2 = findViewById(R.id.editTextText3);
        Button button = findViewById(R.id.button);
        TextView textView = findViewById(R.id.textView5);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = inputEmail.getText().toString().trim();
                String haslo1 = inputHaslo1.getText().toString().trim();
                String haslo2 = inputHaslo2.getText().toString().trim();
                if (!email.isEmpty() && !haslo1.isEmpty() && !haslo2.isEmpty()){
                    if (email.contains("@")){
                        if (haslo1.equals(haslo2)){
                            String[] emailxd = email.split("@");
                            textView.setText("Witaj " + emailxd[0] + "@" + emailxd[1]);
                        }
                        else{
                            textView.setText("Hasła się różnią");
                        }
                    }
                    else {
                        textView.setText("Niepoprawny adres e-mail");
                    }
                }
            }
        });

    }
}