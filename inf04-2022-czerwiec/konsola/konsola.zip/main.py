import random


def wypelnienie(tab):
    for i in range(0, 50, 1):
        tab.append(random.randint(1, 100))

def przeszukiwanie(tab, x):
    tab.append(x)
    i = 0
    while not tab[i] == x:
        i += 1

    if i == len(tab) - 1:
        return f"W tablicy nie znaleziono liczby"
    else:
        return f"Liczba {x} znajduje się w na miejscu: {i + 1}"

if __name__ == '__main__':
    tab = []
    wypelnienie(tab)

    x = int(input("Jaką liczbę chcesz znaleźć: "))

    print(tab)
    print(przeszukiwanie(tab, x))
