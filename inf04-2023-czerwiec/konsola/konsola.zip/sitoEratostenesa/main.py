import math


def wypelnienie_tablicy(A: list):
    for i in range(100):
        A.append(True)


def sito_eratostenesa(A: list):
    n = len(A)
    for i in range(2, int(math.sqrt(n)) + 1):
        if A[i] is True:
            for j in range(i*i, n, i):
                A[j] = False


if __name__ == "__main__":
    A = []
    wypelnienie_tablicy(A)
    sito_eratostenesa(A)

    print('Liczby pierwsze w przedziale od 2 do 100:')
    for i in range(2, 100):
        if A[i] is True:
            print(f'{i} ', end='')

    print()
    x = input("Wciśnij dowolny klawisz...")
