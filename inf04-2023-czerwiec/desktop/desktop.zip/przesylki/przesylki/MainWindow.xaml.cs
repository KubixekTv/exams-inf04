﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace przesylki
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Zatwierdz_Click(object sender, RoutedEventArgs e)
        {
            string kodPocztowy = txtKodPocztowy.Text.Trim();
            if (kodPocztowy.Length == 5)
            {
                if (CzyWszystkoToCyfry(kodPocztowy))
                {
                    MessageBox.Show("Dane przesyłki zostały zapisane", "Sukces", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    MessageBox.Show("Kod pocztowy powinien się składać z samych cyfr", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Nieprawidłowa liczba cyfr w kodzie pocztowym", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private bool CzyWszystkoToCyfry(string text)
        {
            foreach(char znak in text)
            {
                if (!char.IsDigit(znak))
                {
                    return false;
                }
            }
            return true;
        }

        private void Cena_Click(object sender, RoutedEventArgs e)
        {
            if (rbPocztowka.IsChecked == true)
            {
                labCena.Content = "Cena: 1 zł";
                imgPrzesylka.Source = new BitmapImage(new Uri("img/pocztowka.png", UriKind.RelativeOrAbsolute)); //, UriKind.RelativeOrAbsolute
            }
            else if (rbList.IsChecked == true)
            {
                labCena.Content = "Cena: 1,5 zł";
                imgPrzesylka.Source = new BitmapImage(new Uri("img/list.png", UriKind.RelativeOrAbsolute));
            }
            else 
            {
                labCena.Content = "Cena: 10 zł";
                imgPrzesylka.Source = new BitmapImage(new Uri("img/paczka.png", UriKind.RelativeOrAbsolute));
            }
        }
    }
}