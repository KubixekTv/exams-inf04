"""*********************************
nazwa funkcji: plec
opis funkcji: funkcja zwraca 'K' - Kobieta lub 'M' - Mężczyzna na podstawie płci w numerze PESEL
parametry: pesel - numer PESEL
zwracany typ i opis: string - zwracana jest płeć na podstawie wprowadzonego numeru PESEL
autor: 05281104559
*********************************"""
def plec(pesel):
    if int(pesel[9]) % 2 == 0:
        return 'K'
    else:
        return 'M'

def sumaKontrolna(pesel):
    peseltab = []
    waga = [1, 3, 7, 9, 1, 3, 7, 9, 1, 3]
    S = 0
    M = 0
    R = 0

    for i in range(len(pesel) - 1):
        peseltab.append(int(pesel[i]))

    for i in range(len(peseltab)):
        S += peseltab[i] * waga[i]

    M = S % 10
    if M == 0:
        R = 0
    else:
        R = 10 - M

    if R == int(pesel[10]):
        return True
    else:
        return False

if __name__ == '__main__':
    pesel = ''
    while True:
        pesel = str(input('Podaj swój numer PESEL: '))
        if len(pesel) != 11:
            print('Błąd!')
        else:
            break

    print(plec(pesel))
    print(sumaKontrolna(pesel))
