﻿using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace paszporty
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string imie = txtImie.Text.Trim();
            string nazwisko = txtNazwisko.Text.Trim();
            string kolorOczu = RadioButtonColor();

            //imgZdjecie.Source = new BitmapImage(new Uri("000-zdjecie.jpg", UriKind.RelativeOrAbsolute));

            if (string.IsNullOrWhiteSpace(imie) || string.IsNullOrWhiteSpace(nazwisko))
                MessageBox.Show("Podano niepoprawne dane.", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                txtNumer.Clear();
                txtImie.Clear();
                txtNazwisko.Clear();
            else
                MessageBox.Show($"{imie} {nazwisko} ma {kolorOczu} oczy.", "Sukces", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private string RadioButtonColor()
        {
            if (rbNiebieskie.IsChecked == true)
                return "Niebieskie";
            else if (rbZielone.IsChecked == true)
                return "Zielone";
            else
                return "Piwne";
        }

        private void txtNumer_TextChanged(object sender, TextChangedEventArgs e)
        {
            UpdateImages();
        }

        private void UpdateImages()
        {
            string numer = txtNumer.Text.Trim();
            string zdjeciePath = $"{numer}-zdjecie.jpg";
            string odciskPath = $"{numer}-odcisk.jpg";

            Console.WriteLine(zdjeciePath);

            if (File.Exists(zdjeciePath))
            {
                imgZdjecie.Source = new BitmapImage(new Uri(zdjeciePath, UriKind.RelativeOrAbsolute));
            }
            else
            {
                imgZdjecie.Source = null;
            }

            if (File.Exists(odciskPath))
            {
                imgOdcisk.Source = new BitmapImage(new Uri(odciskPath, UriKind.RelativeOrAbsolute));
            }
            else
            {
                imgOdcisk.Source = null;
            }
        }

    }
}